(function(){function e(e){let t=0;for(let n=0;n<e.length;n++){let r=e.charCodeAt(n);t=(t<<5)-t+r,t|=0}return Math.abs(t).toString(36)}function t(t,n,r,i){let a=i.trim().replace(/\s+/g,` `).slice(0,80);return`msg_${e(`${t}_${n}_${(r||``).trim()}_${a}`)}`}var n=[new class{platform=`fiverr`;isMatchingUrl(e){let t=e.toLowerCase();return t.includes(`fiverr.com/inbox`)||t.includes(`fiverr.com/messages`)||t.includes(`fiverr.com/manage_orders`)||t.includes(`fiverr.com/users/`)}extractConversationId(){let e=window.location.href,t=e.match(/fiverr\.com\/inbox\/([^/?#]+)/i);if(t&&t[1])return decodeURIComponent(t[1]);let n=e.match(/fiverr\.com\/messages\/([^/?#]+)/i);if(n&&n[1])return decodeURIComponent(n[1]);let r=e.match(/manage_orders\/([^/?#]+)/i);return r&&r[1]?`order-${r[1]}`:null}extractClientInfo(){let e=this.extractConversationId(),t=[`[data-testid="chat-header-user-name"]`,`[data-testid="conversation-header-name"]`,`.chat-header [class*="username"]`,`.chat-header [class*="user-name"]`,`.chat-header h2`,`.chat-header h3`,`[class*="conversation-header"] [class*="name"]`,`[class*="conversation-header"] h2`,`[class*="chat-header"] a`,`[class*="contact-name"]`,`[class*="recipient-name"]`],n=null;for(let e of t){let t=document.querySelector(e)?.textContent?.trim();if(t&&t.length>0&&t.length<60){n=t;break}}let r=[`[data-testid="chat-header"] img`,`[class*="chat-header"] img`,`[class*="conversation-header"] img`,`.chat-header [role="img"]`,`.conversation-header [role="img"]`],i=null;for(let e of r){let t=document.querySelector(e);if(t&&t.src&&!t.src.includes(`data:image/svg`)){i=t.src;break}}let a=null;return e&&!e.startsWith(`order-`)?a=e:n&&(a=n.toLowerCase().replace(/[^a-z0-9_]/g,`_`)),{username:a,displayName:n,avatarUrl:i}}extractMessages(){let e=this.extractConversationId()||`fiverr_unknown`,n=this.extractClientInfo(),r=n.displayName||n.username||`Client`,i=[`[data-testid="message-item"]`,`[data-testid="chat-message"]`,`[class*="message-item"]`,`[class*="chat-message"]`,`.message-row`,`.chat-row`,`li[class*="message"]`],a=[];for(let e of i){let t=document.querySelectorAll(e);if(t.length>0){a=Array.from(t);break}}let o=[];return a.forEach(n=>{let i=n.querySelector(`[data-testid="message-text"], [class*="message-text"], [class*="message-body"], .message-text, .text-content, p`)?.textContent?.trim()||n.textContent?.trim();if(!i||i.length===0)return;let a=n.classList.contains(`is-me`)||n.classList.contains(`me`)||n.classList.contains(`sent`)||n.classList.contains(`outbound`)||!!n.querySelector(`[class*="is-me"], [class*="outbound"], [data-testid="me"]`),s=n.querySelector(`[data-testid="message-sender"], [class*="sender-name"], .sender, strong`)?.textContent?.trim(),c=a?`seller`:`client`,l=a?`Me`:s||r,u=n.querySelector(`[data-testid="message-time"], [class*="message-time"], [class*="timestamp"], time, .time`)?.textContent?.trim()||null,d=t(e,c,u,i);o.push({id:d,sender:l,senderRole:c,text:i,timestamp:u,isOwn:a})}),o}insertDraft(e){let t=[`textarea[data-testid="message-input"]`,`textarea[name="message"]`,`textarea[placeholder*="message" i]`,`textarea[placeholder*="type" i]`,`div[contenteditable="true"][data-testid="message-input"]`,`div[contenteditable="true"][role="textbox"]`,`.chat-composer textarea`,`#message_body`],n=null;for(let e of t){let t=document.querySelector(e);if(t&&t.offsetParent!==null){n=t;break}}if(!n)return console.warn(`[Memoreply Fiverr] No composer input element detected.`),!1;if(n.focus(),n instanceof HTMLTextAreaElement){let t=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,`value`)?.set;return t?t.call(n,e):n.value=e,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),!0}return n.isContentEditable?(n.textContent=e,n.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),!0):!1}},new class{platform=`upwork`;isMatchingUrl(e){let t=e.toLowerCase();return t.includes(`upwork.com/messages`)||t.includes(`upwork.com/nx/wm`)||t.includes(`upwork.com/ab/messages`)}extractConversationId(){let e=window.location.href,t=e.match(/(?:messages\/rooms|workroom)\/([^/?#]+)/i);if(t&&t[1])return decodeURIComponent(t[1]);let n=new URL(e).searchParams.get(`room`);if(n)return n;let r=document.querySelector(`[data-room-id], [data-qa="room-id"]`);if(r){let e=r.getAttribute(`data-room-id`)||r.getAttribute(`data-qa="room-id"`);if(e)return e}return null}extractClientInfo(){let e=[`[data-test="room-header-title"]`,`header.room-header h2`,`.up-chat-header .up-user-name`,`[data-qa="room-title"]`,`.room-title`,`[data-test="header-name"]`,`.up-user-name`],t=null;for(let n of e){let e=document.querySelector(n)?.textContent?.trim();if(e&&e.length>0&&e.length<70){t=e;break}}let n=[`[data-test="room-header"] img`,`.up-chat-header img`,`.room-header img`,`.up-avatar img`],r=null;for(let e of n){let t=document.querySelector(e);if(t&&t.src&&!t.src.includes(`data:image/svg`)){r=t.src;break}}return{username:t?t.toLowerCase().replace(/[^a-z0-9_]/g,`_`):null,displayName:t,avatarUrl:r}}extractMessages(){let e=this.extractConversationId()||`upwork_room_unknown`,n=this.extractClientInfo().displayName||`Client`,r=[`[data-test="message-item"]`,`.story-message`,`.up-chat-message`,`[data-qa="chat-message"]`,`li[data-test="chat-message"]`,`.message-container`],i=[];for(let e of r){let t=document.querySelectorAll(e);if(t.length>0){i=Array.from(t);break}}let a=[];return i.forEach(r=>{let i=r.querySelector(`[data-test="message-text"], .message-body, .up-chat-message-text, .story-message-text, p`)?.textContent?.trim()||r.textContent?.trim();if(!i||i.length===0)return;let o=r.classList.contains(`is-self`)||r.classList.contains(`up-chat-message--outbound`)||r.classList.contains(`is-outbound`)||!!r.querySelector(`[data-test="outbound-message"], .is-self`),s=r.querySelector(`[data-test="sender-name"], .message-sender, .sender-name, strong`)?.textContent?.trim(),c=o?`seller`:`client`,l=o?`Me`:s||n,u=r.querySelector(`[data-test="message-timestamp"], .message-time, time, .up-chat-message-time`)?.textContent?.trim()||null,d=t(e,c,u,i);a.push({id:d,sender:l,senderRole:c,text:i,timestamp:u,isOwn:o})}),a}insertDraft(e){let t=[`div[contenteditable="true"][data-test="composer-input"]`,`div[contenteditable="true"].ql-editor`,`textarea[data-test="composer-textarea"]`,`textarea.up-chat-composer`,`[data-qa="message-composer-textarea"]`,`div[contenteditable="true"][role="textbox"]`,`textarea.up-textarea`],n=null;for(let e of t){let t=document.querySelector(e);if(t&&t.offsetParent!==null){n=t;break}}if(!n)return console.warn(`[Memoreply Upwork] No composer input element detected.`),!1;if(n.focus(),n instanceof HTMLTextAreaElement){let t=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,`value`)?.set;return t?t.call(n,e):n.value=e,n.dispatchEvent(new Event(`input`,{bubbles:!0})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),!0}if(n.isContentEditable){try{let t=window.getSelection(),r=document.createRange();if(r.selectNodeContents(n),t?.removeAllRanges(),t?.addRange(r),document.execCommand(`insertText`,!1,e))return n.dispatchEvent(new InputEvent(`input`,{bubbles:!0})),!0}catch{}return n.textContent=e,n.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),!0}return!1}},new class{platform=`linkedin`;isMatchingUrl(e){return e.toLowerCase().includes(`linkedin.com/messaging`)}extractConversationId(){let e=window.location.href.match(/messaging\/thread\/([^/?#]+)/i);if(e&&e[1])return decodeURIComponent(e[1]);let t=document.querySelector(`.msg-conversation-listitem--selected, [data-conversation-id].active`);if(t){let e=t.getAttribute(`data-conversation-id`);if(e)return e}return null}extractClientInfo(){let e=[`.msg-entity-lockup__entity-title`,`.msg-conversation-topcard__name`,`h2.msg-conversation-topcard__name`,`[data-view-name="message-thread-topcard-profile-link"]`,`.msg-thread__link-to-profile`,`.msg-title_title`,`a[data-control-name="topcard"]`],t=null;for(let n of e){let e=document.querySelector(n)?.textContent?.trim();if(e&&e.length>0&&e.length<80){t=e;break}}let n=[`.msg-conversation-topcard__photo img`,`.msg-entity-lockup__entity-info img`,`.msg-conversation-card__profile-image img`,`.presence-entity__image`],r=null;for(let e of n){let t=document.querySelector(e);if(t&&t.src&&!t.src.includes(`data:image/svg`)){r=t.src;break}}return{username:t?t.toLowerCase().replace(/[^a-z0-9_]/g,`_`):null,displayName:t,avatarUrl:r}}extractMessages(){let e=this.extractConversationId()||`linkedin_thread_unknown`,n=this.extractClientInfo().displayName||`LinkedIn Contact`,r=[`.msg-s-message-list__event`,`li.msg-s-message-list__item`,`.msg-s-event-listitem`,`[data-event-urn]`],i=[];for(let e of r){let t=document.querySelectorAll(e);if(t.length>0){i=Array.from(t);break}}let a=[];return i.forEach(r=>{let i=r.querySelector(`.msg-s-event-listitem__body, p.msg-s-event-listitem__body, .msg-s-message-group__content p`)?.textContent?.trim()||r.textContent?.trim();if(!i||i.length===0)return;let o=r.classList.contains(`msg-s-message-list__event--from-viewer`)||r.classList.contains(`msg-s-event-listitem--other`)===!1&&!!r.closest(`.msg-s-message-list__event--from-viewer`),s=r.querySelector(`.msg-s-message-group__name, .msg-s-message-group__profile-link, strong`)?.textContent?.trim(),c=o?`seller`:`client`,l=o?`Me`:s||n,u=r.querySelector(`time.msg-s-message-group__timestamp, .msg-s-message-list__time-heading, time`)?.textContent?.trim()||null,d=t(e,c,u,i);a.push({id:d,sender:l,senderRole:c,text:i,timestamp:u,isOwn:o})}),a}insertDraft(e){let t=[`div.msg-form__contenteditable[contenteditable="true"]`,`div[role="textbox"][aria-label*="message" i]`,`div[contenteditable="true"].msg-form__msg-content-container`,`div[contenteditable="true"]`],n=null;for(let e of t){let t=document.querySelector(e);if(t&&t.offsetParent!==null){n=t;break}}if(!n)return console.warn(`[Memoreply LinkedIn] No composer input element detected.`),!1;n.focus();try{let t=window.getSelection(),r=document.createRange();if(r.selectNodeContents(n),t?.removeAllRanges(),t?.addRange(r),document.execCommand(`insertText`,!1,e))return n.dispatchEvent(new InputEvent(`input`,{bubbles:!0})),!0}catch{}return n.innerHTML=`<p>${e.replace(/\n/g,`<br>`)}</p>`,n.dispatchEvent(new InputEvent(`input`,{bubbles:!0,inputType:`insertText`})),n.dispatchEvent(new Event(`change`,{bubbles:!0})),!0}}];function r(e){for(let t of n)if(t.isMatchingUrl(e))return t;return null}var i=[{id:`scope_reminder`,badge:`Scope Reminder`,title:`Polite Scope Boundary`,desc:`Clarifies that extra deliverables require a separate milestone offer.`,getText:e=>`Hi ${e||`there`},\n\nThanks for reaching out! Regarding the additional deliverable requested, that falls outside our original agreed project scope. I'd love to help you get this done—I can set up a quick separate milestone offer at our standard rate so we keep everything organized. Let me know if that sounds good to you!`},{id:`milestone_approval`,badge:`Milestone Done`,title:`Ready for Review & Approval`,desc:`Notifies client of milestone completion and prompts next phase approval.`,getText:e=>`Hi ${e||`there`},\n\nI've completed all items for this milestone as discussed! The updated files are uploaded for your review. Please inspect them and let me know if you have any questions or are ready to approve this milestone so we can start on the next step.`},{id:`rush_delivery`,badge:`Rush Option`,title:`Rush Delivery Overtime Fee`,desc:`Offers early delivery ahead of queue with a dedicated rush fee.`,getText:e=>`Hi ${e||`there`},\n\nUnderstood! Delivering ahead of schedule would require overtime and prioritizing your project ahead of other queue orders. I can definitely make the earlier date work with a rush fee, or we can stick to our confirmed date at the agreed rate. Which do you prefer?`},{id:`platform_terms`,badge:`Safety`,title:`Platform Terms & Safety`,desc:`Keeps all payments, files, and agreements safe inside platform policy.`,getText:e=>`Hi ${e||`there`},\n\nSounds like a plan! Just a quick reminder that all milestone offers, deliverables, and payments will be handled directly through this platform to ensure we're both protected under platform terms. Looking forward to our next steps!`}],a=class{host=null;shadow=null;isExpanded=!1;activeTab=`actions`;clientName=`Client`;messagesCount=0;options;isDragging=!1;startX=0;startY=0;currentX=0;currentY=0;constructor(e){this.options=e}mount(){document.getElementById(`memoreply-floating-root`)||(this.host=document.createElement(`div`),this.host.id=`memoreply-floating-root`,this.host.style.position=`fixed`,this.host.style.zIndex=`2147483647`,this.host.style.bottom=`24px`,this.host.style.right=`24px`,this.host.style.userSelect=`none`,this.shadow=this.host.attachShadow({mode:`open`}),this.render(),document.body.appendChild(this.host),this.attachEvents(),setTimeout(()=>{this.handleExtract(!1)},1200))}updateState(e,t){e&&(this.clientName=e),this.messagesCount=t,this.render()}handleExtract(e=!0){try{let t=this.options.onExtract();t.clientDisplayName&&(this.clientName=t.clientDisplayName),this.messagesCount=t.messagesCount,this.render(),e&&this.showToast(`Extracted ${t.messagesCount} msgs • ${this.clientName}`)}catch{e&&this.showToast(`Could not extract thread.`,!0)}}handleInsertTemplate(e){let t=i.find(t=>t.id===e);if(!t)return;let n=t.getText(this.clientName),r=this.options.onInsertDraft(n);r.success?this.showToast(`Polite reply inserted into composer!`):this.showToast(r.error||`Failed to insert draft`,!0)}handleInsertTerms(){let e=`Hi ${this.clientName||`there`},\n\nHere is a quick summary of our agreed project terms:\n• Platform: ${this.options.platform.toUpperCase()}\n• Milestones: Work deliverables handled as discussed\n• Timeline: Confirmed per platform delivery date\n\nPlease let me know if everything matches your expectations so we can proceed!`,t=this.options.onInsertDraft(e);t.success?this.showToast(`Agreed terms ledger inserted!`):this.showToast(t.error||`Failed to insert terms`,!0)}showToast(e,t=!1){if(!this.shadow)return;let n=this.shadow.getElementById(`mr-toast`);n&&(n.textContent=e,n.style.background=t?`rgba(239, 68, 68, 0.95)`:`rgba(16, 185, 129, 0.95)`,n.style.color=`#ffffff`,n.style.opacity=`1`,n.style.transform=`translateY(0)`,setTimeout(()=>{n&&(n.style.opacity=`0`,n.style.transform=`translateY(10px)`)},2400))}render(){if(!this.shadow)return;let e=this.options.platform.toUpperCase();this.shadow.innerHTML=`
      <style>
        /* ── Memoreply Brand Typography ────────────────────────── */
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
          /* Inter / Geist / SF Pro stack for UI elements */
          font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto,
            "Helvetica Neue", Arial, sans-serif;
        }

        /* JetBrains Mono for version tags, ledger terms, platform chips */
        .mono, code, kbd {
          font-family: "JetBrains Mono", "Fira Code", "Cascadia Code",
            ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          font-feature-settings: "liga" 1, "calt" 1;
        }

        .mr-widget {
          position: relative;
          color: #f4f4f5;
          font-size: 12px;
          line-height: 1.4;
          filter: drop-shadow(0 12px 24px rgba(0, 0, 0, 0.45));
        }

        /* Pill (Minimized) */
        .mr-pill {
          display: flex;
          align-items: center;
          gap: 8px;
          background: #09090b;
          border: 1px solid #27272a;
          padding: 6px 12px;
          border-radius: 9999px;
          cursor: pointer;
          transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          box-shadow: 0 4px 12px rgba(0,0,0,0.3);
        }

        .mr-pill:hover {
          border-color: #3f3f46;
          background: #18181b;
          transform: translateY(-1px);
        }

        .mr-status-dot {
          width: 7px;
          height: 7px;
          border-radius: 9999px;
          background: #10b981;
          box-shadow: 0 0 8px rgba(16, 185, 129, 0.8);
          animation: mr-pulse 2s infinite;
        }

        @keyframes mr-pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.6; transform: scale(0.9); }
        }

        .mr-brand-name {
          font-weight: 700;
          font-size: 11px;
          letter-spacing: -0.02em;
          color: #ffffff;
        }

        .mr-platform-chip {
          font-size: 9px;
          font-family: "JetBrains Mono", "Fira Code", "Cascadia Code", ui-monospace, monospace;
          font-feature-settings: "liga" 1, "calt" 1;
          background: #27272a;
          color: #a1a1aa;
          padding: 2px 6px;
          border-radius: 4px;
          font-weight: 600;
          letter-spacing: 0.04em;
        }

        .mr-msgs-badge {
          font-size: 10px;
          color: #10b981;
          font-weight: 600;
          font-family: "JetBrains Mono", "Fira Code", "Cascadia Code", ui-monospace, monospace;
          font-feature-settings: "liga" 1, "calt" 1;
        }

        /* Expanded Card */
        .mr-card {
          width: 320px;
          background: #09090b;
          border: 1px solid #27272a;
          border-radius: 16px;
          overflow: hidden;
          box-shadow: 0 20px 40px rgba(0, 0, 0, 0.6);
          animation: mr-fade-in 0.18s cubic-bezier(0.16, 1, 0.3, 1);
        }

        @keyframes mr-fade-in {
          from { opacity: 0; transform: scale(0.96) translateY(6px); }
          to { opacity: 1; transform: scale(1) translateY(0); }
        }

        /* Top Accent Beam */
        .mr-laser-beam {
          height: 2px;
          width: 100%;
          background: linear-gradient(90deg, #10b981 0%, #6366f1 50%, transparent 100%);
        }

        /* Card Header */
        .mr-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 10px 14px;
          border-bottom: 1px solid #18181b;
          background: #0d0d10;
          cursor: grab;
        }

        .mr-header-left {
          display: flex;
          align-items: center;
          gap: 6px;
        }

        .mr-drag-handle {
          color: #71717a;
          font-size: 12px;
          margin-right: 2px;
          cursor: grab;
        }

        .mr-header-title {
          font-weight: 700;
          font-size: 12px;
          color: #ffffff;
        }

        .mr-close-btn {
          background: transparent;
          border: none;
          color: #71717a;
          cursor: pointer;
          padding: 4px 6px;
          border-radius: 6px;
          font-size: 11px;
          transition: all 0.15s;
        }

        .mr-close-btn:hover {
          color: #ffffff;
          background: #27272a;
        }

        /* Client Info Row */
        .mr-client-info {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 8px 14px;
          background: #121216;
          border-bottom: 1px solid #18181b;
          font-size: 11px;
        }

        .mr-client-name {
          font-weight: 600;
          color: #e4e4e7;
          display: flex;
          align-items: center;
          gap: 5px;
        }

        /* Tab Switcher */
        .mr-tabs {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          padding: 6px 10px;
          background: #09090b;
          gap: 4px;
          border-bottom: 1px solid #18181b;
        }

        .mr-tab-btn {
          background: transparent;
          border: 1px solid transparent;
          color: #a1a1aa;
          padding: 5px 8px;
          border-radius: 6px;
          font-size: 10.5px;
          font-weight: 600;
          cursor: pointer;
          text-align: center;
          transition: all 0.15s;
        }

        .mr-tab-btn.active {
          background: #18181b;
          border-color: #27272a;
          color: #ffffff;
        }

        .mr-tab-btn:hover:not(.active) {
          color: #e4e4e7;
          background: #121215;
        }

        /* Body Views */
        .mr-body {
          padding: 12px 14px;
          max-height: 280px;
          overflow-y: auto;
        }

        /* Actions View */
        .mr-action-grid {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .mr-btn {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          padding: 8px 12px;
          border-radius: 8px;
          border: 1px solid #27272a;
          background: #18181b;
          color: #f4f4f5;
          font-size: 11.5px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s;
          text-align: left;
        }

        .mr-btn:hover {
          background: #27272a;
          border-color: #3f3f46;
          color: #ffffff;
          transform: translateY(-0.5px);
        }

        .mr-btn-primary {
          background: #10b981;
          color: #09090b;
          border-color: #059669;
          font-weight: 700;
        }

        .mr-btn-primary:hover {
          background: #34d399;
          border-color: #10b981;
          color: #09090b;
        }

        /* Templates View */
        .mr-template-list {
          display: flex;
          flex-direction: column;
          gap: 8px;
        }

        .mr-template-card {
          padding: 8px 10px;
          background: #121216;
          border: 1px solid #27272a;
          border-radius: 8px;
          cursor: pointer;
          transition: all 0.15s;
        }

        .mr-template-card:hover {
          border-color: #6366f1;
          background: #181820;
        }

        .mr-template-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          margin-bottom: 4px;
        }

        .mr-template-badge {
          font-size: 9px;
          font-family: "JetBrains Mono", "Fira Code", "Cascadia Code", ui-monospace, monospace;
          font-feature-settings: "liga" 1, "calt" 1;
          padding: 1px 5px;
          border-radius: 4px;
          background: #1e1b4b;
          color: #818cf8;
          border: 1px solid #312e81;
        }

        .mr-template-title {
          font-weight: 600;
          font-size: 11px;
          color: #f4f4f5;
        }

        .mr-template-desc {
          font-size: 10px;
          color: #a1a1aa;
          line-height: 1.3;
        }

        /* Toast Feedback */
        .mr-toast {
          position: absolute;
          bottom: 10px;
          left: 12px;
          right: 12px;
          padding: 7px 12px;
          border-radius: 8px;
          font-size: 11px;
          font-weight: 600;
          text-align: center;
          box-shadow: 0 4px 14px rgba(0,0,0,0.4);
          opacity: 0;
          transform: translateY(10px);
          transition: all 0.2s cubic-bezier(0.16, 1, 0.3, 1);
          pointer-events: none;
          z-index: 10;
        }

        /* Scrollbar */
        .mr-body::-webkit-scrollbar {
          width: 4px;
        }
        .mr-body::-webkit-scrollbar-thumb {
          background: #27272a;
          border-radius: 4px;
        }
      </style>

      <div class="mr-widget">
        ${this.isExpanded?`
          <!-- Expanded Card View -->
          <div class="mr-card">
            <div class="mr-laser-beam"></div>

            <!-- Header -->
            <div class="mr-header" id="mr-drag-header">
              <div class="mr-header-left">
                <span class="mr-drag-handle">⋮⋮</span>
                <span class="mr-status-dot"></span>
                <span class="mr-header-title">Memoreply Companion</span>
              </div>
              <button class="mr-close-btn" id="mr-collapse-btn" title="Minimize floating bar">
                —
              </button>
            </div>

            <!-- Client Info Row -->
            <div class="mr-client-info">
              <span class="mr-client-name">
                <span>👤</span>
                <span>${this.clientName}</span>
              </span>
              <span class="mr-platform-chip">${e} &bull; ${this.messagesCount} msgs</span>
            </div>

            <!-- Tabs -->
            <div class="mr-tabs">
              <button class="mr-tab-btn ${this.activeTab===`actions`?`active`:``}" data-tab="actions">
                ⚡ Actions
              </button>
              <button class="mr-tab-btn ${this.activeTab===`templates`?`active`:``}" data-tab="templates">
                💬 Replies
              </button>
              <button class="mr-tab-btn ${this.activeTab===`terms`?`active`:``}" data-tab="terms">
                📌 Terms
              </button>
            </div>

            <!-- Body Contents -->
            <div class="mr-body">
              ${this.activeTab===`actions`?`
                <div class="mr-action-grid">
                  <button class="mr-btn mr-btn-primary" id="mr-btn-extract">
                    <span>⚡ Extract Thread Memory</span>
                    <span style="font-size: 10px; font-weight: normal;">Scan DOM &rarr;</span>
                  </button>

                  <button class="mr-btn" id="mr-btn-quick-scope">
                    <span>🛡️ Insert Scope Reminder</span>
                    <span style="color: #a1a1aa; font-size: 10px;">1-Click &rarr;</span>
                  </button>

                  <button class="mr-btn" id="mr-btn-quick-milestone">
                    <span>✅ Insert Milestone Done</span>
                    <span style="color: #a1a1aa; font-size: 10px;">1-Click &rarr;</span>
                  </button>

                  <button class="mr-btn" id="mr-btn-quick-terms">
                    <span>📋 Paste Agreed Terms</span>
                    <span style="color: #a1a1aa; font-size: 10px;">To Composer &rarr;</span>
                  </button>
                </div>
              `:this.activeTab===`templates`?`
                <div class="mr-template-list">
                  ${i.map(e=>`
                    <div class="mr-template-card" data-template-id="${e.id}">
                      <div class="mr-template-header">
                        <span class="mr-template-title">${e.title}</span>
                        <span class="mr-template-badge">${e.badge}</span>
                      </div>
                      <p class="mr-template-desc">${e.desc}</p>
                    </div>
                  `).join(``)}
                </div>
              `:`
                <!-- Terms View -->
                <div style="display: flex; flex-direction: column; gap: 8px;">
                  <div style="background: #121216; border: 1px solid #27272a; border-radius: 8px; padding: 10px; font-size: 11px;">
                    <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                      <span style="color: #71717a;">Client:</span>
                      <span style="color: #ffffff; font-weight: 600;">${this.clientName}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                      <span style="color: #71717a;">Platform:</span>
                      <span style="color: #ffffff; font-weight: 600;">${e}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; margin-bottom: 6px;">
                      <span style="color: #71717a;">Messages Scanned:</span>
                      <span style="color: #10b981; font-weight: 600;">${this.messagesCount}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between;">
                      <span style="color: #71717a;">Memory Status:</span>
                      <span style="color: #10b981; font-weight: 600;">Active Sandbox</span>
                    </div>
                  </div>

                  <button class="mr-btn mr-btn-primary" id="mr-btn-insert-terms-now">
                    <span>📌 Insert Confirmed Terms to Composer</span>
                  </button>
                </div>
              `}
            </div>

            <!-- Toast alert inside shadow root -->
            <div class="mr-toast" id="mr-toast"></div>
          </div>
        `:`
          <!-- Minimized Floating Pill -->
          <div class="mr-pill" id="mr-pill-toggle">
            <span class="mr-status-dot"></span>
            <span class="mr-brand-name">MEMOREPLY</span>
            <span class="mr-platform-chip">${e}</span>
            <span class="mr-msgs-badge">${this.messagesCount>0?`${this.messagesCount} msgs`:`Ready`}</span>
          </div>
        `}
      </div>
    `,this.attachEvents()}attachEvents(){if(!this.shadow)return;let e=this.shadow.getElementById(`mr-pill-toggle`);e&&e.addEventListener(`click`,()=>{this.isExpanded=!0,this.render()});let t=this.shadow.getElementById(`mr-collapse-btn`);t&&t.addEventListener(`click`,()=>{this.isExpanded=!1,this.render()}),this.shadow.querySelectorAll(`.mr-tab-btn`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.getAttribute(`data-tab`);t&&(this.activeTab=t,this.render())})});let n=this.shadow.getElementById(`mr-btn-extract`);n&&n.addEventListener(`click`,()=>this.handleExtract(!0));let r=this.shadow.getElementById(`mr-btn-quick-scope`);r&&r.addEventListener(`click`,()=>this.handleInsertTemplate(`scope_reminder`));let i=this.shadow.getElementById(`mr-btn-quick-milestone`);i&&i.addEventListener(`click`,()=>this.handleInsertTemplate(`milestone_approval`));let a=this.shadow.getElementById(`mr-btn-quick-terms`);a&&a.addEventListener(`click`,()=>this.handleInsertTerms());let o=this.shadow.getElementById(`mr-btn-insert-terms-now`);o&&o.addEventListener(`click`,()=>this.handleInsertTerms()),this.shadow.querySelectorAll(`.mr-template-card`).forEach(e=>{e.addEventListener(`click`,()=>{let t=e.getAttribute(`data-template-id`);t&&this.handleInsertTemplate(t)})});let s=this.shadow.getElementById(`mr-drag-header`);s&&this.host&&s.addEventListener(`mousedown`,e=>{if(e.target.id===`mr-collapse-btn`)return;this.isDragging=!0,this.startX=e.clientX,this.startY=e.clientY;let t=this.host.getBoundingClientRect();this.currentX=t.left,this.currentY=t.top;let n=e=>{if(!this.isDragging||!this.host)return;let t=e.clientX-this.startX,n=e.clientY-this.startY,r=this.currentX+t,i=this.currentY+n,a=window.innerWidth-(this.host.offsetWidth||320),o=window.innerHeight-(this.host.offsetHeight||200);r=Math.max(10,Math.min(r,a-10)),i=Math.max(10,Math.min(i,o-10)),this.host.style.left=`${r}px`,this.host.style.top=`${i}px`,this.host.style.bottom=`auto`,this.host.style.right=`auto`},r=()=>{this.isDragging=!1,window.removeEventListener(`mousemove`,n),window.removeEventListener(`mouseup`,r)};window.addEventListener(`mousemove`,n),window.addEventListener(`mouseup`,r)})}};if(window.location.hostname.includes(`memoreply.com`)||window.location.hostname===`localhost`||window.location.hostname===`127.0.0.1`||window.location.hostname.includes(`vercel.app`)){let e=e=>{if(!e||!e.token&&!e.licenseKey&&!e.userId)return;let t=e.plan||`Agency Pro`,n=e.licenseKey||`MR-${t.toUpperCase().replace(/\s+/g,``)}-ACTIVE-SEC`,r={token:e.token||`clerk_${e.userId||n}`,refreshToken:e.refreshToken||``,userId:e.userId||`usr_${Date.now()}`,email:e.email||`seller@memoreply.com`,name:e.name||`Freelancer`,plan:t,licenseKey:n,authenticatedAt:Date.now()},i=t.toUpperCase()!==`FREE`,a={valid:!0,userId:r.userId,email:r.email,name:r.name,plan:t,isLicensed:i,tier:i?`PAID`:`FREE`,limits:{maxFreeReplies:i?999999:50,repliesUsed:0,isExhausted:!1,upgradeUrl:`https://memoreply.com/pricing`},verifiedAt:Date.now()};chrome.storage.local.set({memoreply_auth_session:r,memoreply_license_status:a,memoreply_license_key:n}).then(()=>{console.log(`[Memoreply Extension Bridge] Session & License Key synchronized:`,n);try{window.dispatchEvent(new CustomEvent(`MEMOREPLY_EXTENSION_SYNCED`,{detail:{synced:!0,email:r.email,plan:r.plan}}))}catch{}})};window.addEventListener(`message`,t=>{t.origin===window.location.origin&&t.data?.type===`MEMOREPLY_AUTH_PAYLOAD`&&t.data?.payload&&e(t.data.payload)});let t=()=>{let t=document.body?.getAttribute(`data-memoreply-auth`);if(t)try{let n=JSON.parse(t);if(n.token||n.licenseKey){e(n);return}}catch{}try{let t=localStorage.getItem(`memoreply_auth_user`);if(t){let n=JSON.parse(t);n&&(n.email||n.licenseKey)&&e({token:n.licenseKey?`sess_${n.licenseKey}`:`web_sess_${n.id||Date.now()}`,userId:n.id,email:n.email,name:n.name,plan:n.plan||`Agency Pro`,licenseKey:n.licenseKey})}}catch{}};t(),setTimeout(t,800),setTimeout(t,2e3),setTimeout(t,4e3),typeof MutationObserver<`u`&&document.body&&new MutationObserver(()=>t()).observe(document.body,{attributes:!0,attributeFilter:[`data-memoreply-auth`]})}console.log(`[Memoreply] Multi-platform content script initialized on:`,window.location.href);function o(){let e=window.location.href;return r(e)?!0:s()}function s(){let e=window.location.href.toLowerCase();return e.includes(`fiverr.com/inbox`)||e.includes(`fiverr.com/messages`)||e.includes(`fiverr.com/manage_orders`)||e.includes(`fiverr.com/users/`)}function c(){let e=window.location.href,t=r(e);if(t){let e=t.extractConversationId();if(e)return e}let n=e.match(/fiverr\.com\/inbox\/([^/?#]+)/i);if(n&&n[1])return decodeURIComponent(n[1]);let i=e.match(/fiverr\.com\/messages\/([^/?#]+)/i);if(i&&i[1])return decodeURIComponent(i[1]);let a=e.match(/manage_orders\/([^/?#]+)/i);return a&&a[1]?`order-${a[1]}`:null}function l(e){if(!e)return null;let t=e.match(/([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/gi);if(t&&t.length>0){let e=t.find(e=>!e.endsWith(`.png`)&&!e.endsWith(`.jpg`)&&!e.includes(`example.com`));return e?e.toLowerCase():null}return null}function u(e){for(let t of e)if(t.senderRole===`client`||!t.isOwn){let e=l(t.text);if(e)return e}let t=document.querySelector(`a[href^="mailto:"]`);if(t){let e=t.href.replace(/^mailto:/i,``).split(`?`)[0].trim();if(e)return e.toLowerCase()}let n=document.querySelector(`[class*="profile"], [class*="contact"], [class*="client-info"], [class*="about-client"]`);if(n&&n.textContent){let e=l(n.textContent);if(e)return e}for(let t of e){let e=l(t.text);if(e)return e}return null}function d(){let e=c(),t=[`[data-testid="chat-header-user-name"]`,`[data-testid="conversation-header-name"]`,`.chat-header [class*="username"]`,`.chat-header [class*="user-name"]`,`.chat-header h2`,`.chat-header h3`,`[class*="conversation-header"] [class*="name"]`,`[class*="conversation-header"] h2`,`[class*="chat-header"] a`,`[class*="contact-name"]`,`[class*="recipient-name"]`],n=null;for(let e of t){let t=document.querySelector(e)?.textContent?.trim();if(t&&t.length>0&&t.length<60){n=t;break}}let r=[`[data-testid="chat-header"] img`,`[class*="chat-header"] img`,`[class*="conversation-header"] img`,`.chat-header [role="img"]`],i=null;for(let e of r){let t=document.querySelector(e);if(t?.src&&!t.src.includes(`data:image/svg`)){i=t.src;break}}let a=n??e;return{username:a,displayName:n??a,avatarUrl:i}}function f(){let e=[],n=new Set,r=c()||`fiverr_chat`,i=[`[data-testid="message-item"]`,`[data-testid="chat-message"]`,`[class*="message-item"]`,`[class*="message-row"]`,`[class*="chat-message"]`,`[class*="message-bubble-wrapper"]`,`[class*="message-wrapper"]`,`[class*="message_item"]`,`[class*="chat_message"]`,`li[class*="message"]`,`div[role="listitem"]`,`.message-bubble-wrapper`,`.chat-box-message`],a=null;for(let e of i){let t=document.querySelectorAll(e);if(t.length>0){a=t;break}}if(!a||a.length===0){let e=document.querySelectorAll(`[class*="message-bubble"], [class*="msg-body"], [class*="message-body"]`);e.length>0&&(a=e)}if(!a||a.length===0)return console.log(`[Memoreply] No message elements matched on this page.`),e;let{displayName:o}=d();return a.forEach(i=>{let a=[`[data-testid="message-text"]`,`[class*="message-text"]`,`[class*="text-content"]`,`[class*="body-text"]`,`[class*="msg-text"]`,`[class*="message-content"]`,`[class*="message-body"]`,`p`].join(`,`),s=(i.querySelector(a)??i).textContent?.trim()??``;if(!s||s.length<1)return;let c=i.className.toLowerCase(),l=c.includes(`own`)||c.includes(`sent`)||c.includes(`outgoing`)||c.includes(`me`)||c.includes(`from-seller`)||c.includes(`sender-me`)||c.includes(`is-own`)||c.includes(`self`)||i.getAttribute(`data-is-own`)===`true`||i.getAttribute(`data-sender`)===`seller`||i.getAttribute(`data-testid`)===`message-from-me`,u=c.includes(`system`)||c.includes(`notice`)||c.includes(`event`)||c.includes(`order-status`),d=u?`system`:l?`seller`:`client`,f=l?`Me`:u?`Fiverr System`:o??`Client`,p=i.querySelector(`time`)??i.querySelector(`[data-testid*="time"]`)??i.querySelector(`[class*="timestamp"]`)??i.querySelector(`[class*="time"]`)??i.querySelector(`[class*="date"]`),m=p?.getAttribute(`datetime`)??p?.textContent?.trim()??null,h=t(r,d,m,s);n.has(h)||(n.add(h),e.push({id:h,sender:f,senderRole:d,text:s,timestamp:m,isOwn:l}))}),e}function p(){let e=r(window.location.href);if(e){let t=e.extractConversationId(),n=e.extractClientInfo(),r=e.extractMessages(),i=u(r),a=r.length>0?`active`:`empty`;return{platform:e.platform,conversationId:t,clientUsername:n.username,clientDisplayName:n.displayName,clientAvatarUrl:n.avatarUrl,clientEmail:i,messages:r,extractedAt:new Date().toISOString(),url:window.location.href,status:a}}let t=s(),n=c(),{username:i,displayName:a,avatarUrl:o}=d(),l=t?f():[],p=u(l),m=`not_found`;return t&&(m=l.length>0?`active`:`empty`),{platform:`fiverr`,conversationId:n,clientUsername:i,clientDisplayName:a,clientAvatarUrl:o,clientEmail:p,messages:l,extractedAt:new Date().toISOString(),url:window.location.href,status:m}}function m(e){if(!e||e.trim().length===0)return{success:!1,error:`Empty draft text provided.`};let t=r(window.location.href);if(t&&t.insertDraft(e))return{success:!0,message:`Draft inserted into ${t.platform.toUpperCase()} composer! Review and send when ready.`};let n=[`textarea[placeholder*="message" i]`,`textarea[placeholder*="type" i]`,`textarea[placeholder*="reply" i]`,`textarea[name="message"]`,`[data-testid="chat-input"] textarea`,`[class*="chat-input"] textarea`,`[class*="composer"] textarea`,`[class*="message-box"] textarea`,`[role="textbox"][contenteditable="true"]`,`[contenteditable="true"]`,`textarea`],i=null;for(let e of n){let t=document.querySelector(e);if(t&&t.offsetParent!==null){i=t;break}}if(!i)return console.warn(`[Memoreply] Could not find composer input on page.`),{success:!1,error:`Could not find message composer on this page. Please make sure the conversation is open.`};try{if(i.focus(),i instanceof HTMLTextAreaElement||i instanceof HTMLInputElement){let t=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,`value`)?.set;t?t.call(i,e):i.value=e,i.dispatchEvent(new Event(`input`,{bubbles:!0})),i.dispatchEvent(new Event(`change`,{bubbles:!0}))}else i.getAttribute(`contenteditable`)===`true`&&(document.execCommand(`insertText`,!1,e)||(i.textContent=e),i.dispatchEvent(new InputEvent(`input`,{bubbles:!0,data:e})));return i.focus(),i.scrollIntoView({behavior:`smooth`,block:`center`}),console.log(`[Memoreply] Draft inserted into composer successfully (not sent).`),{success:!0,message:`Draft inserted into composer! Review and send when ready.`}}catch(e){return console.error(`[Memoreply] Error inserting draft:`,e),{success:!1,error:`Failed to insert draft: ${String(e)}`}}}chrome.runtime.onMessage.addListener((e,t,n)=>{switch(e.type){case`PING`:{let e=r(window.location.href);return n({success:!0,data:{platform:e?e.platform:`fiverr`,isInbox:o(),url:window.location.href}}),!1}case`EXTRACT_CONVERSATION`:try{let e=p(),t=`currentConversation_${e.platform||`fiverr`}`;chrome.storage.local.set({currentConversation:e,[t]:e}).catch(()=>{}),n({success:!0,data:e,message:`Extracted ${e.messages.length} messages.`})}catch(e){n({success:!1,error:`Failed to extract conversation: ${String(e)}`})}return!1;case`INSERT_DRAFT`:return n(m(e.payload?.text??``)),!1;default:return!1}});var h=``;function g(){if(o())try{let e=p(),t=`${e.conversationId}_${e.messages.length}_${e.messages[e.messages.length-1]?.id??``}`;if(t!==h&&e.messages.length>0){h=t,console.log(`[Memoreply] Auto-detected ${e.messages.length} messages for ${e.clientDisplayName??`Client`} (${e.platform}).`);let n=`currentConversation_${e.platform||`fiverr`}`;chrome.storage.local.set({currentConversation:e,[n]:e}).catch(()=>{}),chrome.runtime.sendMessage({type:`CONVERSATION_EXTRACTED`,payload:e},()=>{chrome.runtime.lastError}),_?_.updateState(e.clientDisplayName,e.messages.length):v()}}catch(e){console.warn(`[Memoreply] Background extraction warning:`,e)}}var _=null;function v(){if(_||!o())return;let e=r(window.location.href);_=new a({platform:e?e.platform:`fiverr`,onExtract:()=>{let e=p();return{clientDisplayName:e.clientDisplayName,messagesCount:e.messages.length,platform:e.platform,conversationId:e.conversationId}},onInsertDraft:e=>m(e)}),_.mount()}document.readyState===`loading`?document.addEventListener(`DOMContentLoaded`,v):v(),setTimeout(g,900),setTimeout(g,2400);var y=null;new MutationObserver(()=>{o()&&(_||v(),y&&window.clearTimeout(y),y=window.setTimeout(g,800))}).observe(document.body,{childList:!0,subtree:!0}),setInterval(()=>{!_&&o()&&v(),g()},4e3);})()
