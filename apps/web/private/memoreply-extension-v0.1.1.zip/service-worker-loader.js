import './assets/background.ts-B8nr3nXa.js';
